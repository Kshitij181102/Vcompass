import React, { useEffect, useState } from 'react'
import { Outlet, Navigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import apis from '../utils/apis'

const Super = () => {
    const [isAuth, setIsAuth] = useState(false)
    const [loading, setLoading] = useState(true)

    useEffect(() => {
        const getRouteAccess = async () => {
            try {
                setLoading(true)
                const response = await fetch(apis().getAccess, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    credentials: 'include', // passToken cookie sent automatically
                })
                const result = await response.json()
                if (!response.ok) {
                    throw new Error(result?.message)
                }
                if (result?.status) {
                    setIsAuth(true)
                }
            } catch (error) {
                toast.error(error.message)
            } finally {
                setLoading(false)
            }
        }
        getRouteAccess();
    }, [])

    if (loading) return <h2>loading...</h2>

    return isAuth ? <Outlet /> : <Navigate to="/login" />
}

export default Super