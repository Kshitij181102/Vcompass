import React, { useEffect, useState } from "react";
import { Navigate } from "react-router-dom";
import apis from "../utils/apis";

const ProtectedRoute = ({ children }) => {
  const [isAuth, setIsAuth] = useState(null); // null = still checking

  useEffect(() => {
    const verify = async () => {
      try {
        const response = await fetch(apis().getUserProfile, {
          method: "GET",
          credentials: "include", // send cookie to server
        });
        setIsAuth(response.ok);
      } catch {
        setIsAuth(false);
      }
    };
    verify();
  }, []);

  if (isAuth === null) return null; // still verifying — render nothing briefly

  return isAuth ? children : <Navigate to="/login" replace />;
};

export default ProtectedRoute;
