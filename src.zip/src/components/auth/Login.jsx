import React, { useState } from "react";
import Input from "../ui/Input";
import Button from "../ui/Button";
import { Link, useNavigate } from "react-router-dom";
import apis from "../../utils/apis";
import toast from "react-hot-toast";
import LoadingButton from "../ui/LoadingButton";
import logo from "../../Assets/logo.png";
import { Eye, EyeOff, ArrowRight, Compass } from "lucide-react";
import "./Login.css";

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const emailChange = (e) => setEmail(e.target.value);
  const passwordChange = (e) => setPassword(e.target.value);

  const submitHandler = async (e) => {
    e.preventDefault();
    try {
      setLoading(true);
      const response = await fetch(apis().loginUser, {
        method: "POST",
        body: JSON.stringify({ email, password }),
        headers: { "Content-Type": "application/json" },
        credentials: "include",
      });

      const result = await response.json();
      setLoading(false);

      if (!response.ok) {
        toast.error(result?.message || "Login failed");
        return;
      }

      if (result?.status) {
        toast.success(result.message || "Login successful");
        sessionStorage.setItem("disId", result.disId);
        navigate("/main");
      }
    } catch (err) {
      toast.error(err.message || "Something went wrong");
      setLoading(false);
    }
  };

  return (
    <div className="login-root">
      {/* Left Panel */}
      <div className="login-left">
        <div className="login-left-inner">
          <div className="login-brand">
            <div className="login-logo-wrap">
              <img src={logo} alt="V-Compass" className="login-logo-img" />
            </div>
            <span className="login-brand-name">V-Compass</span>
          </div>

          <div className="login-hero-text">
            <h1 className="login-headline">
              Navigate Your<br />
              <span className="login-headline-accent">Future.</span>
            </h1>
            <p className="login-subheadline">
              Connect with world-class mentors who guide you toward the career and life you envision.
            </p>
          </div>

          <div className="login-stats">
            <div className="login-stat">
              <span className="login-stat-num">2.4k+</span>
              <span className="login-stat-label">Mentors</span>
            </div>
            <div className="login-stat-divider" />
            <div className="login-stat">
              <span className="login-stat-num">18k+</span>
              <span className="login-stat-label">Sessions</span>
            </div>
            <div className="login-stat-divider" />
            <div className="login-stat">
              <span className="login-stat-num">96%</span>
              <span className="login-stat-label">Satisfaction</span>
            </div>
          </div>

          <div className="login-testimonial">
            <p className="login-testimonial-text">
              "V-Compass changed the trajectory of my career within 3 months."
            </p>
            <div className="login-testimonial-author">
              <div className="login-avatar">AK</div>
              <div>
                <p className="login-author-name">Arjun Kumar</p>
                <p className="login-author-role">Software Engineer @ Google</p>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative orbs */}
        <div className="login-orb login-orb-1" />
        <div className="login-orb login-orb-2" />
        <div className="login-orb login-orb-3" />
      </div>

      {/* Right Panel */}
      <div className="login-right">
        <div className="login-form-container">
          <div className="login-form-header">
            <h2 className="login-form-title">Welcome back</h2>
            <p className="login-form-subtitle">Sign in to continue your journey</p>
          </div>

          <form onSubmit={submitHandler} className="login-form">
            <div className="login-field">
              <label className="login-label">Email Address</label>
              <Input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={emailChange}
                required
              />
            </div>

            <div className="login-field">
              <label className="login-label">Password</label>
              <div className="login-password-wrap">
                <Input
                  type={showPassword ? "text" : "password"}
                  placeholder="Enter your password"
                  value={password}
                  onChange={passwordChange}
                  required
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="login-eye-btn"
                  tabIndex={-1}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </div>

            <div className="login-forgot-row">
              <Link to="/forget/password" className="login-forgot-link">
                Forgot password?
              </Link>
            </div>

            <Button type="submit">
              <LoadingButton loading={loading} title="Sign In" />
              {!loading && <ArrowRight size={18} />}
            </Button>
          </form>

          <p className="login-register-prompt">
            Don't have an account?{" "}
            <Link to="/register" className="login-register-link">
              Create one free
            </Link>
          </p>

          <p className="login-terms">
            By signing in, you agree to our{" "}
            <a href="/terms">Terms of Service</a> and{" "}
            <a href="/privacy">Privacy Policy</a>.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
