import React, { useState } from "react";
import { Eye, EyeOff, User, Mail, Lock, MessageSquare, ArrowRight, CheckCircle, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import logo from "../../Assets/logo.png";
import Input from "../ui/Input";
import LoadingButton from "../ui/LoadingButton";
import Button from "../ui/Button";
import apis from "../../utils/apis";
import toast from "react-hot-toast";
import "./Register.css";

const steps = ["Account", "Profile", "Done"];

const Register = () => {
  const [showPassword, setShowPassword] = useState(false);
  const [step, setStep] = useState(0);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [disId, setDisId] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const goNext = (e) => {
    e.preventDefault();
    if (step === 0) {
      if (!email || !password) {
        toast.error("Please fill in email and password.");
        return;
      }
      setStep(1);
    }
  };

  const submitHandler = async (event) => {
    event.preventDefault();
    if (!name || !email || !password || !disId) {
      toast.error("Please fill in all the fields.");
      return;
    }

    try {
      setLoading(true);
      const response = await fetch(apis().registerUser, {
        method: "POST",
        body: JSON.stringify({ name, email, password, disId }),
        headers: { "Content-Type": "application/json" },
      });

      const result = await response.json();
      setLoading(false);

      if (!response.ok) throw new Error(result?.message || "Registration failed");
      if (result?.status) {
        toast.success(result?.message || "Account created!");
        setStep(2);
        setTimeout(() => navigate("/login"), 2000);
      }
    } catch (error) {
      toast.error(error.message);
      setLoading(false);
    }
  };

  return (
    <div className="reg-root">
      {/* Background Mesh */}
      <div className="reg-bg-mesh" />

      {/* Top bar */}
      <header className="reg-topbar">
        <div className="reg-brand">
          <div className="reg-logo-wrap">
            <img src={logo} alt="V-Compass" className="reg-logo-img" />
          </div>
          <span className="reg-brand-name">V-Compass</span>
        </div>
        <button className="reg-signin-btn" onClick={() => navigate('/login')}>
          <ArrowLeft size={15} />
          Sign In
        </button>
      </header>

      {/* Main content */}
      <main className="reg-main">
        {/* Left info column */}
        <div className="reg-info">
          <div className="reg-info-badge">Start for free</div>
          <h1 className="reg-info-headline">
            Your compass<br />
            to <span className="reg-info-accent">greatness</span>.
          </h1>
          <p className="reg-info-body">
            Join thousands of learners who found clarity, direction, and momentum with V-Compass mentorship.
          </p>

          <div className="reg-features">
            {[
              "Verified expert mentors across 50+ fields",
              "1-on-1 personalized sessions",
              "Track goals and milestones",
              "Community & peer learning",
            ].map((f, i) => (
              <div className="reg-feature" key={i}>
                <span className="reg-feature-dot" />
                {f}
              </div>
            ))}
          </div>

          <div className="reg-avatars">
            {["RK", "SM", "PJ", "AL", "KD"].map((a, i) => (
              <div className="reg-avatar-chip" key={i} style={{ zIndex: 5 - i }}>
                {a}
              </div>
            ))}
            <span className="reg-avatars-text">+2,400 mentors waiting</span>
          </div>
        </div>

        {/* Form card */}
        <div className="reg-card-wrap">
          {/* Step indicator */}
          <div className="reg-steps">
            {steps.map((s, i) => (
              <React.Fragment key={i}>
                <div className={`reg-step ${i <= step ? 'reg-step-active' : ''} ${i < step ? 'reg-step-done' : ''}`}>
                  <div className="reg-step-circle">
                    {i < step ? <CheckCircle size={14} /> : <span>{i + 1}</span>}
                  </div>
                  <span className="reg-step-label">{s}</span>
                </div>
                {i < steps.length - 1 && (
                  <div className={`reg-step-line ${i < step ? 'reg-step-line-done' : ''}`} />
                )}
              </React.Fragment>
            ))}
          </div>

          <div className="reg-card">
            {/* Step 0: Account credentials */}
            {step === 0 && (
              <form onSubmit={goNext} className="reg-form">
                <div className="reg-form-header">
                  <h2 className="reg-form-title">Create account</h2>
                  <p className="reg-form-subtitle">Start with your login credentials</p>
                </div>

                <div className="reg-field">
                  <label className="reg-label">Email Address</label>
                  <div className="reg-input-icon-wrap">
                    <Mail size={17} className="reg-input-icon" />
                    <Input
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      type="email"
                      placeholder="you@example.com"
                      required
                    />
                  </div>
                </div>

                <div className="reg-field">
                  <label className="reg-label">Password</label>
                  <div className="reg-input-icon-wrap">
                    <Lock size={17} className="reg-input-icon" />
                    <Input
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      type={showPassword ? "text" : "password"}
                      placeholder="Create a strong password"
                      required
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="reg-eye-btn"
                      tabIndex={-1}
                    >
                      {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
                    </button>
                  </div>
                  <p className="reg-hint">Use 8+ characters with letters and numbers</p>
                </div>

                <Button type="submit">
                  Continue
                  <ArrowRight size={17} />
                </Button>
              </form>
            )}

            {/* Step 1: Profile details */}
            {step === 1 && (
              <form onSubmit={submitHandler} className="reg-form">
                <div className="reg-form-header">
                  <h2 className="reg-form-title">Your profile</h2>
                  <p className="reg-form-subtitle">Tell us a little about yourself</p>
                </div>

                <div className="reg-field">
                  <label className="reg-label">Full Name</label>
                  <div className="reg-input-icon-wrap">
                    <User size={17} className="reg-input-icon" />
                    <Input
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      type="text"
                      placeholder="Your full name"
                      required
                    />
                  </div>
                </div>

                <div className="reg-field">
                  <label className="reg-label">Discord ID</label>
                  <div className="reg-input-icon-wrap">
                    <MessageSquare size={17} className="reg-input-icon" />
                    <Input
                      value={disId}
                      onChange={(e) => setDisId(e.target.value)}
                      type="text"
                      placeholder="e.g. username#1234"
                      required
                    />
                  </div>
                  <p className="reg-hint">Used to connect you with your mentor on Discord</p>
                </div>

                <div className="reg-form-actions">
                  <button type="button" className="reg-back-btn" onClick={() => setStep(0)}>
                    <ArrowLeft size={16} />
                    Back
                  </button>
                  <div className="reg-submit-wrap">
                    <Button type="submit">
                      <LoadingButton loading={loading} title="Create Account" />
                      {!loading && <ArrowRight size={17} />}
                    </Button>
                  </div>
                </div>
              </form>
            )}

            {/* Step 2: Success */}
            {step === 2 && (
              <div className="reg-success">
                <div className="reg-success-icon">
                  <CheckCircle size={40} strokeWidth={1.5} />
                </div>
                <h2 className="reg-success-title">You're in!</h2>
                <p className="reg-success-body">
                  Your account has been created successfully. Redirecting to sign in…
                </p>
                <div className="reg-success-bar">
                  <div className="reg-success-progress" />
                </div>
              </div>
            )}
          </div>

          <p className="reg-terms">
            By registering, you agree to our{" "}
            <a href="/terms">Terms of Service</a> and{" "}
            <a href="/privacy">Privacy Policy</a>.
          </p>
        </div>
      </main>
    </div>
  );
};

export default Register;
